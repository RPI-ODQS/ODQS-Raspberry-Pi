#!/usr/bin/python

from ubidots import ApiClient
import csv
import sys

class DataStore:
	
	def __init__(self, fileName, token, temperatureVariables, pressureVariables, waterFlowVariable, currentVariable):
		
		self.fileName = fileName
		self.token = token
		
		self.temperatureVariables = temperatureVariables[:]
		self.pressureVariables = pressureVariables[:]
		self.waterFlowVariable = waterFlowVariable[:]
		self.currentVariable = currentVariable[:]
		
	
		#Create an "API" object
		self.api = ApiClient(token=self.token)


	def setToken(self, token):
		self.token = token
		self.api = ApiClient(token=self.token)
		
	def setTempVariables(self, tempVarList):
		self.temperatureVariables = tempVarList[:]
	
	def setPressureVariables(self, presVarList):
		self.pressureVariables = presVarList[:]
		
	def setCurrentVariables(self, curVarList):
		self.currentVariable = curVarList[:]
		
	def setFlowRateVariables(self, flowRateVarList):
		self.waterFlowVariable = flowRateVarList[:]
	
	def saveAllData(self, temperature, pressure, flowRate, current):
		data = []
		
		for i in range(len(temperature)):
			data.append({'variable': self.temperatureVariables[i], 'value': temperature[i]})
		
		for i in range(len(pressure)):
			data.append({'variable': self.pressureVariables[i], 'value': pressure[i]})
		
		for i in range(len(flowRate)):
			data.append({'variable': self.waterFlowVariable[i], 'value': flowRate[i]})
		
		for i in range(len(current)):
			data.append({'variable': self.currentVariable[i], 'value': current[i]})
		
		try:
			self.api = ApiClient(token=self.token)
			self.api.save_collection(data)
		except ConnectionError as e:
			print("Data not send to Ubidots:", e)
			
		try:
			f = open(self.fileName,'a')
			writer = csv.writer(f)
			for element in data:
				writer.writerow( (element['variable'], element['value']) )
		except IOError:
			print "Could not write to file:", self.fileName
		finally:
			f.close()


