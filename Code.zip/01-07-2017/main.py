#!/usr/bin/python

import time
import datetime

import pigpio
from temperature import *
from water_flow_sensor import *
from switch_motor import *
from pwm_motor import *
from pressure_and_current_sensor import *
from button import *
from ubi import *






try:

	pi = pigpio.pi()
	
	if not pi.connected:
		print("Pigpio error")
		exit(0)
	
	#default CE pin is CE0 (GPIO 8), default MOSI, MISO, SCLK are used
	TempSensor = Temperature(pi)
	
	# default GPIO pin is 23
	WaterSensor1 = WaterFlow(pi)
	
	WaterSensor2 = WaterFlow(pi, 24)
	

	#default GPIO pins are pinMain = 21, pinControl1 = 20, pinControl2 = 16, pinControl3 = 12, pinControl4 = 25
	SwMotor = SwitchMotor(pi) 
	
	#default GPIO pins are pinMain = 26, pinControl1 = 19, pinControl2 = 13, pinControl3 = 6, pinControl4 = 5
	PwmMotor = PWMMotor(pi) 
	
	#default CE pin is CE0 (GPIO 8), default MOSI, MISO, SCLK are used
	pressure = Pressure(pi)
	current = Current(pi)
	
	btn = Button(pi, 17)
	
	token = 'NiMi8SLq6aLVX38HTNYYGwHqXxqpmW'
	
	tempVariables = ['5957bd48762542549090cb8a', '5957bd8876254254920bc36a', '5957bd907625425491eab6f7', '5957bd97762542549090d070', '5957bda0762542548f763b71']
	waterPressureVariables = ['5957bdef762542548f7640a6', '5957bdf776254254920bc9fb']
	flowRateVariables = ['5957bdc576254254920bc733', '5957bdd276254254920bc7ee']	
	currentVariables = ['5957c28f76254254920c1688', '5957c2977625425491eb06c6', '5957be41762542549090da18', '5957be4276254254938c6b07']
	
	saveData = DataStore('data.csv', token, tempVariables, waterPressureVariables, flowRateVariables, currentVariables)
	
	print "SwMotor"
	SwMotor.startMotor()
	time.sleep(2)
	
	SwMotor.setControlOn(1)
	time.sleep(2)
	
	SwMotor.setControlOff(1)
	time.sleep(2)
	
	SwMotor.stopMotor()
	time.sleep(1)
	
	print "PmwMotor"
	print "Starting"
	PwmMotor.startMotor()
	time.sleep(2)
	print "Started"
	
	PwmMotor.setControlLevel(1, 50)
	time.sleep(2)
	
	PwmMotor.setControlOff(1)
	time.sleep(2)
	
	PwmMotor.stopMotor()
	
	print btn.isDown()
	print btn.isUp()
	
	start = datetime.datetime.now()
	
	while True:


		
		temp = []
		# Loop sensor channels
		for temp_chanel in range(5):
			## Read the temp sensor data
			temp.append(TempSensor.getTemp(temp_chanel))

			## Print out results
			print("Temp  from chanel {}: {} deg C".format(temp_chanel, temp[temp_chanel]))    


		
		

		
		
		pres = []
		pres.append(pressure.getPressure(0))
		pres.append(pressure.getPressure(1))
		
		print("WaterPressure: {} MPa".format(pres[0]))    
		print("WaterPressure: {} MPa".format(pres[1]))    
		#print "--------------------------------------------"  

		flowRate = []
		flowRate.append(WaterSensor1.getFlowRate())
		flowRate.append(WaterSensor2.getFlowRate())
		print("WaterFlow: {} Litres per Hour".format(flowRate[0]))
		print("WaterFlow: {} Litres per Hour".format(flowRate[1]))    
		
		cur = []
		cur.append(current.calcIrms(0,1480))
		cur.append(current.calcIrms(1,1480))
		cur.append(current.calcIrms(2,1480))
		cur.append(current.calcIrms(3,1480))
		
		print("Current: {} A".format(cur[0]))    
		print("Current: {} A".format(cur[1]))    
		print("Current: {} A".format(cur[2]))    
		print("Current: {} A".format(cur[3]))    
		print "--------------------------------------------"  
		
		
		print("nowSleeping")
		
		#wait 1 second
		elapsed_ms = 0
		while(elapsed_ms < 1000):
			end = datetime.datetime.now()
			diff = end - start
			elapsed_ms = (diff.days * 86400000) + (diff.seconds * 1000) + (diff.microseconds / 1000)
		
		saveData.saveAllData(temp, pres, flowRate, cur)
		
		start = datetime.datetime.now()
		
finally: 
 
	TempSensor.delete()
	
	WaterSensor1.delete()
	WaterSensor2.delete()
	
	SwMotor.delete();
	PwmMotor.delete();
	
	pressure.delete()
	current.delete()
	
	pi.stop()
	print "Goodbye"
